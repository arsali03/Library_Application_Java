/*
Author Ali Arslan
*/
package DataBase.Users;
import View.StudentHomepage;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import DataBase.Users.UserController;
import DataBase.Users.UserFactory;
import DataBase.Users.UserService;
import DataBase.Users.User;
import View.Login;
import java.util.List;
import java.sql.Connection;
import DataBase.DatabaseConnection;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class UserController {
    
    private UserService userService;
    private User loggedInUser;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    public void registerUser(String firstName, String lastName, String username, String password, UserType userType, String phoneNumber, String email) {
        userService.registerUser(firstName, lastName, username, password, userType, phoneNumber, email);
    }
    
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return userService.loginUser(enteredUsername, enteredPassword);
    }

    public User getLoggedInUser() {
        return userService.getLoggedInUser();
    }
    
    public boolean deleteUser(User loggedInUser) {
        try {
            if (loggedInUser != null) {
                
                // Kullanıcı varsa, silme işlemini gerçekleştir
                boolean isUserDeleted = userService.deleteUser(loggedInUser);

                if (isUserDeleted) {
                    // Kullanıcı başarıyla silindiğinde yapılacak işlemler
                    System.out.println("Kullanıcı başarıyla silindi.");
                    return true;
                } else {
                    System.out.println("Kullanıcı silinemedi.");
                }
            } else {
                System.out.println("Kullanıcı bulunamadı.");
            }
        } catch (Exception e) {
            // Diğer hataları yakala ve yazdır
            e.printStackTrace();
            System.out.println("Kullanıcı silme işlemi sırasında bir hata oluştu: " + e.getMessage());
        }

        return false;
    }
    
    public boolean updateUserInfo(User user, String newFirstName, String newLastName, String newEmail, String newPhoneNumber) {
        try {
            user.updateUserInfo(newFirstName, newLastName, newEmail, newPhoneNumber);
            return userService.updateUser(user);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean adminUpdateUser(String username, String newFirstName, String newLastName, String newEmail, String newPhoneNumber, String newPassword) {
        try {
            User userToUpdate = userService.getUserByUsername(username);

            if (userToUpdate != null) {
                userToUpdate.setFirstName(newFirstName);
                userToUpdate.setLastName(newLastName);
                userToUpdate.setEmail(newEmail);
                userToUpdate.setPhoneNumber(newPhoneNumber);
                userToUpdate.setPassword(newPassword);

                return userService.adminUpdateUser(userToUpdate);
            } else {
                System.out.println("Kullanıcı bulunamadı.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Kullanıcı güncelleme işlemi sırasında bir hata oluştu: " + e.getMessage());
            return false;
        }
    }      
    
    
    public boolean updatePassword(User user, String newPassword) {
        return userService.updateUserPassword(user, newPassword);
    }
    
    public int getLibraryUserCount() {
        try {
            return userService.getLibraryUserCount();
        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Hata durumunda -1 dönebilirsiniz.
        }
    }
    
    public int getTotalBookCount() {
        try {
            return userService.getTotalBookCount();
        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Hata durumunda -1 dönebilirsiniz.
        }
    }
    
    public int getBorrowedBookCount() {
        try {
            return userService.getBorrowedBookCount();
        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Hata durumunda -1 dönebilirsiniz.
        }
    }
    
    public boolean isUsernameExists(String username) {
    // Veritabanında username kontrolü yapılacak SQL sorgusu
    String sql = "SELECT COUNT(*) FROM users WHERE username = ?";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        preparedStatement.setString(1, username);

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return false;
    }
    
    public void displaySearchResults(List<User> searchResults, DefaultTableModel tableModel) {
        // Önceden eklenmiş olan tablo başlıklarını kullanıcı
        // ID, ad ve soyad bilgileriyle güncelle
        tableModel.setRowCount(0);

        // Arama sonuçlarını tabloya ekle
        for (User user : searchResults) {
            tableModel.addRow(new Object[]{user.getUsername(),user.getFirstName(), user.getLastName()});
        }
    }
    
    public List<User> searchUsersByName(String name) {
        return userService.searchUsersByName(name);
    }
    
    public User getUserByUsername(String username) {
        try {
            return userService.getUserByUsername(username);
        } catch (Exception e) {
            // Hata durumunda işlemleri burada yapabilirsiniz
            e.printStackTrace();
            return null;
        }
    }
    
    

  
}


