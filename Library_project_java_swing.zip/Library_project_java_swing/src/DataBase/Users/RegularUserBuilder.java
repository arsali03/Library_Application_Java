/*
Author Ali Arslan
*/
package DataBase.Users;

public class RegularUserBuilder {
    
    
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private UserType userType;
    private String phoneNumber;
    private String email;
    
    
    public RegularUserBuilder setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public RegularUserBuilder setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public RegularUserBuilder setUsername(String username) {
        this.username = username;
        return this;
    }

    public RegularUserBuilder setPassword(String password) {
        this.password = password;
        return this;
    }

    public RegularUserBuilder setUserType(UserType userType) {
        this.userType = userType;
        return this;
    }

    public RegularUserBuilder setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    public RegularUserBuilder setEmail(String email) {
        this.email = email;
        return this;
    }

    public RegularUser build() {
        return new RegularUser(firstName, lastName, username, password, userType, phoneNumber, email);
    }
    
    // Özür dilerim, builder metodunu eklemeyi unutmuşum
    public static RegularUserBuilder builder() {
        return new RegularUserBuilder();
    }
}

