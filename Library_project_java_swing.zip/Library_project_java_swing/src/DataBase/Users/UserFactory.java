/*
Author Ali Arslan
*/
package DataBase.Users;

import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class UserFactory {
    
    public abstract User createUser(String firstName, String lastName, String username, String password, UserType userType, String phoneNumber, String email);
    
     public abstract User createUserFromResultSet(ResultSet resultSet) throws SQLException;
    
}
