/*
Author Ali Arslan
*/
package DataBase.Users;

import java.sql.SQLException;
import java.sql.ResultSet;

public class AdminUserFactory extends UserFactory{
    @Override
    public User createUser(String firstName, String lastName, String username, String password, UserType userType, String phoneNumber, String email) {
        return new AdminUser(firstName, lastName, username, password, userType, phoneNumber, email);
    }
    
    // ResultSet'ten gelen verilere göre AdminUser nesnesi oluşturacak metod
    @Override
    public User createUserFromResultSet(ResultSet resultSet) throws SQLException {
        return new AdminUser(
                resultSet.getString("first_name"),
                resultSet.getString("last_name"),
                resultSet.getString("username"),
                resultSet.getString("password"),
                UserType.valueOf(resultSet.getString("user_type")),
                resultSet.getString("phone_number"),
                resultSet.getString("email")
        );
    }
}


