/*
Author Ali Arslan
*/
package DataBase.Users;

public enum UserType {
    ADMIN("admin"),
    USER("user");

    private final String userType;

    UserType(String userType) {
        this.userType = userType;
    }

    public String getValue() {
        return userType;
    }
    
    public static UserType fromString(String userType) {
        for (UserType type : UserType.values()) {
            if (type.getValue().equalsIgnoreCase(userType)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Geçersiz UserType: " + userType);
    }
}

