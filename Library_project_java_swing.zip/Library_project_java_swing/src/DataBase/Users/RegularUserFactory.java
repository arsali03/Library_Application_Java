/*
Author Ali Arslan
*/
package DataBase.Users;

import java.sql.ResultSet;
import java.sql.SQLException;


public class RegularUserFactory extends UserFactory{
    @Override
    public User createUser(String firstName, String lastName, String username, String password, UserType userType, String phoneNumber, String email) {
        return new RegularUser(firstName, lastName, username, password, userType, phoneNumber, email);
    }

    public User createUserFromResultSet(ResultSet resultSet) throws SQLException {
    String userTypeString = resultSet.getString("user_type");
    UserType userType = UserType.fromString(userTypeString);

    return new RegularUser(
        resultSet.getString("first_name"),
        resultSet.getString("last_name"),
        resultSet.getString("username"),
        resultSet.getString("password"),
        userType,
        resultSet.getString("phone_number"),
        resultSet.getString("email")
    );
}

}
