/*
Author Ali Arslan
*/
package DataBase.Users;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public abstract class User {
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private UserType userType;
    private String phoneNumber;
    private String email;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public User(String firstName, String lastName, String username, String password, UserType userType, String phoneNumber, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.userType = userType;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }
    
    // Varsayılan olarak eklenen metod
    public void updateUserInfo(String newFirstName, String newLastName, String newEmail, String newPhoneNumber) {
        this.setFirstName(newFirstName);
        this.setLastName(newLastName);
        this.setEmail(newEmail);
        this.setPhoneNumber(newPhoneNumber);
    }
    
     public void register() {
        String sql = "INSERT INTO users (first_name, last_name, username, password, user_type, phone_number, email) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DataBase.DatabaseConnection.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, username);
            preparedStatement.setString(4, password);
            preparedStatement.setString(5, userType.toString()); // Enum değerini kullanmak için toString() metodu
            preparedStatement.setString(6, phoneNumber);
            preparedStatement.setString(7, email);

            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(null, "Kullanıcı başarıyla kaydedildi.");
            } else {
                JOptionPane.showMessageDialog(null, "Kullanıcı kaydedilirken bir hata oluştu.");
          
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int getUserIdByUsername(String username) {
        String sql = "SELECT user_id FROM users WHERE username = ?";
        int userId = -1;

        try (Connection connection = DataBase.DatabaseConnection.getInstance().getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setString(1, username);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // Veritabanından kullanıcı ID'sini al
                userId = resultSet.getInt("user_id");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return userId;
    }

}
