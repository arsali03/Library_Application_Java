package DataBase.Users;
/*
Author Ali Arslan
*/

import DataBase.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class UserService {
    
    private UserFactory userFactory;
    private User loggedInUser;

    public UserService(UserFactory userFactory) {
        this.userFactory = userFactory;
    }

    public void registerUser(String firstName, String lastName, String username, String password, UserType userType, String phoneNumber, String email) {
        User user = userFactory.createUser(firstName, lastName, username, password, userType, phoneNumber, email);
        user.register();
    }
    
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";

        try (Connection connection = DataBase.DatabaseConnection.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setString(1, enteredUsername);
            preparedStatement.setString(2, enteredPassword);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // Kullanıcı nesnesini UserFactory üzerinden oluştur
                loggedInUser = userFactory.createUserFromResultSet(resultSet);
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public User getLoggedInUser() {
        return loggedInUser;
    }
    
    public boolean deleteUser(User userToDelete) {
    try {
        System.out.println(userToDelete.getUsername());
        System.out.println(userToDelete.getFirstName());
        System.out.println(userToDelete.getLastName());
        System.out.println(userToDelete.getUserType());
        System.out.println(userToDelete.getPhoneNumber());
        String sql = "DELETE FROM users WHERE username = ?";

        try (Connection connection = DataBase.DatabaseConnection.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setString(1, userToDelete.getUsername());

            int affectedRows = preparedStatement.executeUpdate();

            // Eğer en az bir satır etkilenmişse, silme işlemi başarılıdır
            return affectedRows > 0;
        }
    } catch (SQLException e) {
        System.out.println("Kullanıcı silme işlemi sırasında bir hata oluştu: " + e.getMessage());
    }

    return false;
}
    
    public boolean updateUser(User user) throws SQLException {
    String sql = "UPDATE users SET first_name=?, last_name=?, email=?, phone_number=? WHERE username=?";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        preparedStatement.setString(1, user.getFirstName());
        preparedStatement.setString(2, user.getLastName());
        preparedStatement.setString(3, user.getEmail());
        preparedStatement.setString(4, user.getPhoneNumber());
        preparedStatement.setString(5, user.getUsername());

        int affectedRows = preparedStatement.executeUpdate();

        return affectedRows > 0;
    }catch(SQLException e){
        
        e.printStackTrace();
        return false;
    }   
    }
    
    public boolean updateUserPassword(User user, String newPassword) {
        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("UPDATE users SET password = ? WHERE username = ?")) {

            preparedStatement.setString(1, newPassword);
            preparedStatement.setString(2, user.getUsername());

            int affectedRows = preparedStatement.executeUpdate();

            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public int getLibraryUserCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM users";
        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        }
        return 0; // Eğer kullanıcı yoksa 0 dönebilirsiniz.
    }
    
    public int getTotalBookCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM books";
        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        }
        return 0; // Eğer kitap yoksa 0 dönebilirsiniz.
    }
    
    public int getBorrowedBookCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM borrows ";
        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        }
        return 0; // Eğer ödünç alınan kitap yoksa 0 dönebilirsiniz.
    }
    
    public List<User> searchUsersByName(String name) {
        List<User> searchResults = new ArrayList<>();

        // Veritabanında ad ve soyada göre kullanıcı araması yapılacak SQL sorgusu
        String sql = "SELECT username,first_name, last_name FROM users WHERE first_name LIKE ? OR last_name LIKE ?";

        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            // SQL sorgusuna parametreleri ekleyin
            preparedStatement.setString(1, "%" + name + "%");
            preparedStatement.setString(2, "%" + name + "%");

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    //  ad ve soyad bilgilerini alarak RegularUser nesnesi oluşturun
                    RegularUser user = RegularUser.builder()
                        .setUsername(resultSet.getString("username"))
                        .setFirstName(resultSet.getString("first_name"))
                        .setLastName(resultSet.getString("last_name"))
                        .build();
                    
                    searchResults.add(user);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return searchResults;
    }
    
    public User getUserByUsername(String username) {
        // Veritabanında username'e göre kullanıcı araması yapılacak SQL sorgusu
        String sql = "SELECT * FROM users WHERE username = ?";

        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setString(1, username);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    // Veritabanından kullanıcı bilgilerini alarak RegularUser nesnesi oluşturun
                    return RegularUser.builder()
                            .setFirstName(resultSet.getString("first_name"))
                            .setLastName(resultSet.getString("last_name"))
                            .setUsername(resultSet.getString("username"))
                            .setPassword(resultSet.getString("password"))
                            .setPhoneNumber(resultSet.getString("phone_number"))
                            .setEmail(resultSet.getString("email"))
                            .build();
                }
            }
        } catch (SQLException e) {
            // Hata durumunda işlemleri burada yapabilirsiniz
            e.printStackTrace();
        }

        return null;
    }
    
    public boolean adminUpdateUser(User user) throws SQLException {
    String sql = "UPDATE users SET first_name=?, last_name=?, email=?, phone_number=?, password=? WHERE username=?";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        preparedStatement.setString(1, user.getFirstName());
        preparedStatement.setString(2, user.getLastName());
        preparedStatement.setString(3, user.getEmail());
        preparedStatement.setString(4, user.getPhoneNumber());
        preparedStatement.setString(5, user.getPassword()); // Eğer şifre değiştirilecekse
        preparedStatement.setString(6, user.getUsername());

        int affectedRows = preparedStatement.executeUpdate();

        return affectedRows > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

    
     /*public User getUserByUsernameAndLastName(String username, String lastName) {
    // Veritabanında username ve lastName'e göre kullanıcı araması yapılacak SQL sorgusu
    String sql = "SELECT * FROM users WHERE username = ? AND last_name = ?";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        preparedStatement.setString(1, username);
        preparedStatement.setString(2, lastName);

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
        if (resultSet.next()) {
            // Veritabanından kullanıcı bilgilerini alarak RegularUser nesnesi oluşturun
            RegularUser user = RegularUser.builder()
                    .setFirstName(resultSet.getString("first_name"))
                    .setLastName(resultSet.getString("last_name"))
                    .setUsername(resultSet.getString("username"))
                    .setPassword(resultSet.getString("password"))
                    .setUserType(UserType.valueOf(resultSet.getString("user_type")))
                    .setPhoneNumber(resultSet.getString("phone_number"))
                    .setEmail(resultSet.getString("email"))
                    .build();

            return user;
        }
    }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return null;
}*/
    
   
   
}
