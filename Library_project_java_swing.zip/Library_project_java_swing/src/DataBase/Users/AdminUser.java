/*
Author Ali Arslan
*/
package DataBase.Users;

public class AdminUser extends User {
    
    public AdminUser(String firstName, String lastName, String username, String password, UserType userType, String phoneNumber, String email) {
        super(firstName, lastName, username, password, userType, phoneNumber, email);
    }
    
    
}
