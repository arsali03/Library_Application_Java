/*
Author Ali Arslan
*/
package DataBase.Users;

public class RegularUser extends User{
    
    public RegularUser(String firstName, String lastName, String username, String password, UserType userType, String phoneNumber, String email ) {
        super(firstName, lastName, username, password, userType, phoneNumber,email);
    }
    
    public static RegularUserBuilder builder() {
        return new RegularUserBuilder();
    }
}
