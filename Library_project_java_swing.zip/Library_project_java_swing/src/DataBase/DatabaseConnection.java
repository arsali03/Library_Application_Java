package DataBase;
/*
Author Ali Arslan
*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/library";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private Connection connection;

    // Yapılan değişiklik: Instance'ı saklamak için static bir değişken ekledik.
    private static DatabaseConnection instance;

    // Yapılan değişiklik: Constructor'ı private olarak tanımladık.
    private DatabaseConnection() {
        // Constructor özel olarak tanımlandı, dışarıdan erişim engelleniyor.
    }

    // Yapılan değişiklik: Singleton örneği almak için static bir metod ekledik.
    public static DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }

    // getConnection metodunu static olmayan bir şekilde değiştirdik.
    public Connection getConnection() {
    try {
        if (connection == null || connection.isClosed()) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Veritabanına bağlantı sağlandı.");
        }
    } catch (ClassNotFoundException | SQLException e) {
        e.printStackTrace();
    }
    
    return connection;
}

    // closeConnection metodunu static olmayan bir şekilde değiştirdik.
    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Veritabanı bağlantısı kapatıldı.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
