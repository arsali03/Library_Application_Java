package DataBase.Books;
/*
Author Ali Arslan
*/
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import DataBase.DatabaseConnection;
import DataBase.Users.User;
import java.awt.Component;
import java.time.LocalDateTime;
import javax.swing.JOptionPane;

public class BookBuilder {
    private String bookName;
    private String author;
    private String subject;
    private BookStatus bookStatus;
    private JTable editBookTable;

    public BookBuilder setBookName(String bookName) {
        this.bookName = bookName;
        return this;
    }

    public BookBuilder setAuthor(String author) {
        this.author = author;
        return this;
    }

    public BookBuilder setSubject(String subject) {
        this.subject = subject;
        return this;
    }

    public BookBuilder setBookStatus(BookStatus bookStatus) {
        this.bookStatus = bookStatus;
        return this;
    }

    public BookBuilder setEditBookTable(JTable editBookTable) {
        this.editBookTable = editBookTable;
        return this;
    }

    public Book build() {
        return new ConcreteBook(bookName, author, subject, bookStatus);
    }

   
public List<Book> searchBooksByFilters(String bookName, String author, String subject) {
    List<Book> searchResults = new ArrayList<>();
    String sql = "SELECT * FROM books WHERE (book_name LIKE ?) AND (author LIKE ?) AND (subject LIKE ?)";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        // Arama sorgusunu parametre ile doldur
        preparedStatement.setString(1, "%" + bookName + "%");
        preparedStatement.setString(2, "%" + author + "%");
        preparedStatement.setString(3, "%" + subject + "%");

        // Sorguyu çalıştır ve sonuçları al
        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                // Get the status from the result set
                String statusFromDB = resultSet.getString("book_status");

                // Map the status to the corresponding BookStatus enum value
                BookStatus status = statusFromDB.equals("borrowed") ? BookStatus.BORROWED : BookStatus.AVAILABLE;

                Book book = new ConcreteBook(
                        resultSet.getString("book_name"),
                        resultSet.getString("author"),
                        resultSet.getString("subject"),
                        status
                );
                searchResults.add(book);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return searchResults;
}


    
    public void addTBorrowDatabaseBook(int userId, int SelectedRowIndex, String formattedDate, String return_date) {
    // Veritabanına ödünç alma bilgisi ekleme SQL sorgusu
    String sql = "INSERT INTO borrows (user_id, book_id, borrow_date, return_date) VALUES (?, ?, ?, ?)";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        // SQL sorgusuna parametreleri ekleyin
        
        preparedStatement.setInt(1, userId);
        preparedStatement.setInt(2, SelectedRowIndex);
        preparedStatement.setString(3, formattedDate);
        preparedStatement.setString(4, return_date);
        

        // Sorguyu çalıştırın
        preparedStatement.executeUpdate();

        // Başarıyla eklendiğini kullanıcıya bildirebilirsiniz
        System.out.println("Kitap veritabanına eklendi: " + bookName);

    } catch (SQLException e) {
        e.printStackTrace();
    }

}
    

    public boolean addToDatabaseBook(String bookName, String author, String subject, String bookStatus) {
    // Veritabanına kitap ekleme SQL sorgusu
    String sql = "INSERT INTO books (book_name, author, subject, book_status) VALUES (?, ?, ?, ?)";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        // SQL sorgusuna parametreleri ekleyin
        preparedStatement.setString(1, bookName);
        preparedStatement.setString(2, author);
        preparedStatement.setString(3, subject);
        preparedStatement.setString(4, bookStatus);

        // Sorguyu çalıştırın
        int affectedRows = preparedStatement.executeUpdate();

        System.out.println("Kitap veritabanına eklendi: " + bookName);

        // Eğer en az bir satır etkilendiyse başarılı kabul ediyoruz
        return affectedRows > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false; // Hata durumunda başarısız kabul ediyoruz
    }
}


    public void deleteFromDatabase(String bookName) {
        // Veritabanından kitap silme SQL sorgusu
        String sql = "DELETE FROM books WHERE book_name = ?";

        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            // SQL sorgusuna parametre ekleyin
            preparedStatement.setString(1, bookName);

            // Sorguyu çalıştırın
            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Kitap veritabanından silindi: " + bookName);
            } else {
                System.out.println("Kitap silinemedi: " + bookName + " bulunamadı.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void makeAvailableBookStatusInDatabase(String oldBookName) {
    // Yeni durumu otomatik olarak "borrowed" yap
    BookStatus newStatus = BookStatus.AVAILABLE;

    // Veritabanında sadece kitap durumu güncelleme SQL sorgusu
    String sql = "UPDATE books SET book_status = ? WHERE book_name = ?";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        // SQL sorgusuna parametreleri ekleyin
        preparedStatement.setString(1, newStatus.toString());
        preparedStatement.setString(2, oldBookName);

        // Sorguyu çalıştırın
        int affectedRows = preparedStatement.executeUpdate();

        if (affectedRows > 0) {
            System.out.println("Kitap durumu güncellendi: " + oldBookName + " -> " + newStatus);
        } else {
            System.out.println("Kitap durumu güncellenemedi: " + oldBookName + " bulunamadı.");
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    public void makeBorrowedBookStatusInDatabase(String oldBookName) {
    // Yeni durumu otomatik olarak "borrowed" yap
    BookStatus newStatus = BookStatus.BORROWED;

    // Veritabanında sadece kitap durumu güncelleme SQL sorgusu
    String sql = "UPDATE books SET book_status = ? WHERE book_name = ?";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        // SQL sorgusuna parametreleri ekleyin
        preparedStatement.setString(1, newStatus.toString());
        preparedStatement.setString(2, oldBookName);

        // Sorguyu çalıştırın
        int affectedRows = preparedStatement.executeUpdate();

        if (affectedRows > 0) {
            System.out.println("Kitap durumu güncellendi: " + oldBookName + " -> " + newStatus);
        } else {
            System.out.println("Kitap durumu güncellenemedi: " + oldBookName + " bulunamadı.");
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
}


    public void updateInDatabaseBook(String oldBookName, Book updatedBook) {
        // Veritabanında kitap güncelleme SQL sorgusu
        String sql = "UPDATE books SET book_name = ?, author = ?, subject = ?, book_status = ? WHERE book_name = ?";

        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            // SQL sorgusuna parametreleri ekleyin
            preparedStatement.setString(1, updatedBook.getBookName());
            preparedStatement.setString(2, updatedBook.getAuthor());
            preparedStatement.setString(3, updatedBook.getSubject());
            preparedStatement.setString(4, updatedBook.getBookStatus().toString());
            preparedStatement.setString(5, oldBookName);

            // Sorguyu çalıştırın
            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Kitap bilgileri güncellendi: " + oldBookName);
            } else {
                System.out.println("Kitap güncellenemedi: " + oldBookName + " bulunamadı.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void displaySearchResults(List<Book> searchResults, JTable table) {
        // DefaultTableModel nesnesi oluştur
        DefaultTableModel tableModel = new DefaultTableModel();

        // Tablo başlıklarını ayarla
        tableModel.setColumnIdentifiers(new Object[]{"Kitap Adı", "Yazar", "Konu"});

        // Arama sonuçları tabloya ekle
        for (Book book : searchResults) {
            tableModel.addRow(new Object[]{book.getBookName(), book.getAuthor(), book.getSubject()});
        }

        // editBookTable'a tablo modelini ayarla
        if (table != null) {
            table.setModel(tableModel);
        } else {
            System.err.println("Uyarı: Tablo null. Tablo modeli ayarlanamadı.");
        }
    }
    public List<Book> getAllBooksFromDatabase() {
        List<Book> allBooks = new ArrayList<>();

        String sql = "SELECT * FROM books";

        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                // Get the status from the result set using the correct column name
                String statusFromDB = resultSet.getString("book_status");

                // Map the status to the corresponding BookStatus enum value
                BookStatus status = statusFromDB.equals("borrowed") ? BookStatus.BORROWED : BookStatus.AVAILABLE;

                Book book = new ConcreteBook(
                        resultSet.getString("book_name"),
                        resultSet.getString("author"),
                        resultSet.getString("subject"),
                        status
                );
                allBooks.add(book);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return allBooks;
    }


        public List<Book> getBorrowBooksFromDatabase() {
    List<Book> borrowBooks = new ArrayList<>();

    String sql = "SELECT * FROM borrows WHERE book_status = 'borrowed'";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         Statement statement = connection.createStatement();
         ResultSet resultSet = statement.executeQuery(sql)) {

        while (resultSet.next()) {
            Book book = new ConcreteBook(
                    resultSet.getString("book_name"),
                    resultSet.getString("author"),
                    resultSet.getString("subject"),
                    BookStatus.BORROWED
            );
            borrowBooks.add(book);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return borrowBooks;
}


    public List<Book> searchBooksByName(String bookName) {
    List<Book> searchResults = new ArrayList<>();

    String sql = "SELECT * FROM books WHERE book_name LIKE ?";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        // Arama sorgusunu parametre ile doldur
        preparedStatement.setString(1, "%" + bookName + "%");

        // Sorguyu çalıştır ve sonuçları al
        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                // Get the status from the result set using the correct column name
                 String statusFromDB = resultSet.getString("book_status");

                // Map the status to the corresponding BookStatus enum value
                BookStatus status = statusFromDB.equals("borrowed") ? BookStatus.BORROWED : BookStatus.AVAILABLE;

                Book book = new ConcreteBook(
                        resultSet.getString("book_name"),
                        resultSet.getString("author"),
                        resultSet.getString("subject"),
                        status
                );
                searchResults.add(book);
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return searchResults;
}

    public Book searchBookById(int id) {
    Book result = null;

    String sql = "SELECT * FROM books WHERE book_id = ?";

    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        // Arama sorgusunu parametre ile doldur
        preparedStatement.setInt(1, id);

        // Sorguyu çalıştır ve sonuçları al
        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            if (resultSet.next()) {
                // Get the status from the result set using the correct column name
               String statusFromDB = resultSet.getString("book_status");

                // Map the status to the corresponding BookStatus enum value
                 BookStatus status = statusFromDB.equals("borrowed") ? BookStatus.BORROWED : BookStatus.AVAILABLE;

                result = new ConcreteBook(
                        resultSet.getString("book_name"),
                        resultSet.getString("author"),
                        resultSet.getString("subject"),
                        status
                );
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return result;
}
    public class SearchBook {
    // Diğer değişkenleri buraya ekleyin

    private JTable editBookTable;

    // Diğer metodları buraya ekleyin

    // editBookTable'ı set etmek için bir metod ekleyebilirsiniz
    public void setEditBookTable(JTable editBookTable) {
        this.editBookTable = editBookTable;
    }

    // editBookTable'ı get etmek için bir metod ekleyebilirsiniz
    public JTable getEditBookTable() {
        return editBookTable;
    }
}
    
    //arama yapılan kitap editbook için aşağıdakiler
    public void searchAndDisplayBooks(String bookName, String bookId, JTable editBookTable, Component parentComponent) {
        bookName = bookName.trim();
        bookId = bookId.trim();

        // Eğer hem kitap adı hem de kitap ID girilmişse, hata mesajı ver
        if (!bookName.isEmpty() && !bookId.isEmpty()) {
            JOptionPane.showMessageDialog(parentComponent, "Lütfen sadece kitap adı veya kitap ID giriniz.");
            return;
        }

        // Kitap adına göre arama yap
        if (!bookName.isEmpty()) {
            List<Book> searchResults = searchBooksByName(bookName);
            displaySearchResults(searchResults, editBookTable);
        }

        // Kitap ID'ye göre arama yap
        if (!bookId.isEmpty()) {
            try {
                int id = Integer.parseInt(bookId);
                Book searchResult = searchBookById(id);
                if (searchResult != null) {
                    List<Book> searchResults = new ArrayList<>();
                    searchResults.add(searchResult);
                    displaySearchResults(searchResults, editBookTable);
                } else {
                    JOptionPane.showMessageDialog(parentComponent, "Kitap bulunamadı.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(parentComponent, "Geçersiz kitap ID.");
            }
        }
    }
    
    public void fetchDataAndDisplayTable(JTable editBookTable) {
        BookBuilder bookBuilder = new BookBuilder();
    DefaultTableModel tableModel = new DefaultTableModel();
    
    // Sütun isimlerini önce ekleyin
    tableModel.setColumnIdentifiers(new Object[]{"Adı", "Yazar", "Konu", "Durum"});

    List<Book> allBooks = bookBuilder.getAllBooksFromDatabase();

    for (Book book : allBooks) {
        if (book.getBookStatus() == BookStatus.BORROWED) {
            String bookStatusText = (book.getBookStatus() == BookStatus.AVAILABLE) ? "MEVCUT" : "ODUNC_ALINDI";
            tableModel.addRow(new Object[]{book.getBookName(), book.getAuthor(), book.getSubject(), bookStatusText});
        }
    }

    // JTable'a modeli set et
    editBookTable.setModel(tableModel);

    }


        //bütün kitaplar
     public void displayAllBooks(JTable editBookTable) {
        // Veritabanından tüm kitapları al
        List<Book> allBooks = getAllBooksFromDatabase();

        // DefaultTableModel nesnesi oluştur
        DefaultTableModel tableModel = new DefaultTableModel();

        // Tablo başlıklarını ayarla
        tableModel.setColumnIdentifiers(new Object[]{"Kitap Adı", "Yazar", "Konu"});

        // Tüm kitapları tabloya ekle
        for (Book book : allBooks) {
            tableModel.addRow(new Object[]{book.getBookName(), book.getAuthor(), book.getSubject()});
        }

        // EditBook sınıfındaki tabloyu güncelle
        editBookTable.setModel(tableModel);
    }
     
     //aşağıdaki kodalar searcbook için arama yapılan kod
      public void displaySearchResults2(List<Book> searchResults, JTable table) {
        // DefaultTableModel nesnesi oluştur
        DefaultTableModel tableModel = new DefaultTableModel();

        // Tablo başlıklarını ayarla
        tableModel.setColumnIdentifiers(new Object[]{"Kitap Adı", "Yazar", "Konu", "Durum"});

        // Arama sonuçlarını tabloya ekle
        for (Book book : searchResults) {
            // Durumu kontrol et ve yazıyı ayarla
            String bookStatusText = (book.getBookStatus() == BookStatus.BORROWED) ? "ODUNC_ALINDI" : "MEVCUT";

            tableModel.addRow(new Object[]{book.getBookName(), book.getAuthor(), book.getSubject(), bookStatusText});
        }

        // JTable'ın modelini güncelle
        table.setModel(tableModel);
    }
      public void displayBorrowBooksOnTable(DefaultTableModel tableModel) {
        List<Book> borrowBooks = getBorrowBooksFromDatabase();

        // Tüm kitapları tabloya ekle
        for (Book book : borrowBooks) {
            // Durumu kontrol et ve yazıyı ayarla
            String bookStatusText = (book.getBookStatus() == BookStatus.AVAILABLE) ? "MEVCUT" : "ODUNC_ALINDI";

            tableModel.addRow(new Object[]{book.getBookName(), book.getAuthor(), book.getSubject(), bookStatusText});
        }
    }
      //bütün kitaplar ekrana getiren kod
       public void displayAllBooksOnTable(DefaultTableModel tableModel) {
        List<Book> allBooks = getAllBooksFromDatabase();

        // Tüm kitapları tabloya ekle
        for (Book book : allBooks) {
            // Durumu kontrol et ve yazıyı ayarla
            String bookStatusText = (book.getBookStatus() == BookStatus.BORROWED) ? "ODUNC_ALINDI" : "MEVCUT";

            tableModel.addRow(new Object[]{book.getBookName(), book.getAuthor(), book.getSubject(), bookStatusText});
        }
    }
       
       
}