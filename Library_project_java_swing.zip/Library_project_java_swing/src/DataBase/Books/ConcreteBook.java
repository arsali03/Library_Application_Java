/*
Author Ali Arslan
*/
package DataBase.Books;

public class ConcreteBook extends Book {

    // Yapıcı metodunuzu güncelleyin
    public ConcreteBook(String bookName, String author, String subject,BookStatus bookStatus){
        super(bookName,author,subject,bookStatus);
     
    }

    // Diğer metodlar
}

