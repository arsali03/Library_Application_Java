/*
Author Ali Arslan
*/
package DataBase.Books;

public enum BookStatus {
    AVAILABLE,
    BORROWED,
    DEFAULT_STATUS,
}
