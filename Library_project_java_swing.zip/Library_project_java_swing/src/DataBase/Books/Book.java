package DataBase.Books;
/*
Author Ali Arslan
*/

public abstract class Book {
    private String bookName;
    private String author;
    private String subject;
    private BookStatus bookStatus;

    // Constructor
    public Book(String bookName, String author, String subject, BookStatus bookStatus) {
        this.bookName = bookName;
        this.author = author;
        this.subject = subject;
        this.bookStatus = bookStatus;
    }

    // Getter ve Setter Metodları
    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public BookStatus getBookStatus() {
        return bookStatus;
    }

    public void setBookStatus(BookStatus bookStatus) {
        this.bookStatus = bookStatus;
    }

    
}
