EmailSender 


package DataBase.observers;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import java.util.Random;

import java.net.Authenticator;

import java.util.Random;

public class EmailSender {

    public static void sendVerificationCode(String toEmail) {
        // Rastgele 6 haneli kod üret
        String verificationCode = generateRandomCode();

        // E-posta gönderimi için gerekli konfigürasyon
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com"); // Gmail'in SMTP sunucu bilgisi
        properties.put("mail.smtp.port", "587"); // Gmail'in SMTP sunucu portu
        properties.put("mail.smtp.auth", "true"); // Kimlik doğrulama kullanılacak mı?
        properties.put("mail.smtp.starttls.enable", "true"); // TLS kullanılacak mı?
        properties.put("mail.smtp.connectiontimeout", "5000"); // Bağlantı süresi
        properties.put("mail.smtp.timeout", "5000"); // İşlem süresi

        // Gmail kimlik bilgileri
        String username = "your-email@gmail.com"; // Gmail adresiniz
        String password = "your-gmail-password"; // Gmail şifreniz


        // Mail oturumu açma
        Session session = Session.getDefaultInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            // MimeMessage oluşturma
            Message mimeMessage = new MimeMessage(session);
            mimeMessage.setFrom(new InternetAddress(username)); // Gönderen
            mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail)); // Alıcı
            mimeMessage.setSubject("Doğrulama Kodu");
            mimeMessage.setText("Hesabınızı doğrulamak için kullanılacak kod: " + verificationCode);

            // E-posta gönderme
            Transport.send(mimeMessage);

            System.out.println("E-posta başarıyla gönderildi.");

        } catch (MessagingException e) {
            e.printStackTrace();
            System.out.println("E-posta gönderimi sırasında bir hata oluştu: " + e.getMessage());
        }
    }

    public static String generateRandomCode() {
        // 6 haneli rastgele bir sayı oluştur
        int code = new Random().nextInt(900000) + 100000;
        return String.valueOf(code);
    }
}