/*
Author Ali Arslan
*/
package DataBase;
import DataBase.Users.RegularUserFactory;
import DataBase.Users.UserController;
import DataBase.Users.UserFactory;
import DataBase.Users.UserService;
import View.Login;
import View.Register;
import java.sql.Connection;

public class Main {
    public static void main(String[] args) {
        
        UserFactory userFactory = new RegularUserFactory(); // veya AdminUserFactory
        UserService userService = new UserService(userFactory);
        UserController userController = new UserController(userService);
        
        // Register penceresini başlatırken UserController'ı parametre olarak verin
        Login login = new Login();
        login.setVisible(true);
        
        
        
    }
}

