package View;
/*
Author Ali Arslan
*/
import DataBase.Books.Book;
import DataBase.Books.BookBuilder;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import DataBase.DatabaseConnection;
import DataBase.Users.RegularUserFactory;
import DataBase.Users.User;
import DataBase.Users.UserController;
import DataBase.Users.UserService;
import com.mysql.cj.conf.PropertyKey;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.SQLException;
import java.awt.Color;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;


public class SearchBook extends javax.swing.JFrame {
    private UserController userController;
    private User loggedInUser;
    private DefaultTableModel tableModel;
    private JTable editBookTable;
    BookBuilder bookBuilder = new BookBuilder();

    // Diğer metodları buraya ekleyin
   
    public SearchBook(User loggedInUser) {
        initComponents();
        setTitle("Kütüphane Uygulaması - Kitap Arama");
        setSize(600, 400);
        setResizable(false);
        setLocation(400, 200);
        getContentPane().setBackground(new Color(40, 40, 40));
        // initializeComponents metodunu burada çağırın
        initializeComponents();
        // loggedInUser'ı başlatın
        this.loggedInUser = loggedInUser;
        if (loggedInUser == null) {
            // loggedInUser null ise, bir hata mesajı gösterilebilir
            JOptionPane.showMessageDialog(this, "Giriş yapmış bir kullanıcı bulunamadı.", "Hata", JOptionPane.ERROR_MESSAGE);
            // ya da bir hata durumunu nasıl ele almak istediğinize karar verin.
        }
        
    }
    
    private void initializeComponents() {
        userController = new UserController(new UserService(new RegularUserFactory()));
        this.loggedInUser = userController.getLoggedInUser();

        // Add the following lines to initialize kitapAraTable
        tableModel = new DefaultTableModel(new Object[]{"Kitap Adı", "Yazar", "Konu", "Durum"}, 0);
        kitapAraTable.setModel(tableModel);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        kitapAraTable = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        searchBookAdTextField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        searchBookYazarTextField = new javax.swing.JTextField();
        searchBookAramaYapButton = new javax.swing.JButton();
        searchBookKonuTextField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        searchBookTumKitapGosterButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        searchBookKitapOduncAlButton = new javax.swing.JButton();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 153));

        jPanel3.setBackground(new java.awt.Color(0, 102, 153));

        kitapAraTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "Kitap Adı", "Yazar", "Konu", "Durum"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(kitapAraTable);
        if (kitapAraTable.getColumnModel().getColumnCount() > 0) {
            kitapAraTable.getColumnModel().getColumn(0).setResizable(false);
            kitapAraTable.getColumnModel().getColumn(1).setResizable(false);
            kitapAraTable.getColumnModel().getColumn(2).setResizable(false);
            kitapAraTable.getColumnModel().getColumn(3).setResizable(false);
        }

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 313, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 301, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        jPanel4.setBackground(new java.awt.Color(0, 102, 153));

        jLabel1.setBackground(new java.awt.Color(0, 102, 153));
        jLabel1.setForeground(new java.awt.Color(0, 153, 204));
        jLabel1.setText("Ad:");

        searchBookAdTextField.setBackground(new java.awt.Color(204, 204, 204));
        searchBookAdTextField.setForeground(new java.awt.Color(51, 51, 51));
        searchBookAdTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBookAdTextFieldActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(0, 102, 153));
        jLabel2.setForeground(new java.awt.Color(0, 153, 204));
        jLabel2.setText("Yazar:");

        searchBookYazarTextField.setBackground(new java.awt.Color(204, 204, 204));
        searchBookYazarTextField.setForeground(new java.awt.Color(51, 51, 51));
        searchBookYazarTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBookYazarTextFieldActionPerformed(evt);
            }
        });

        searchBookAramaYapButton.setBackground(new java.awt.Color(51, 51, 51));
        searchBookAramaYapButton.setForeground(new java.awt.Color(0, 153, 204));
        searchBookAramaYapButton.setText("Arama Yap");
        searchBookAramaYapButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBookAramaYapButtonActionPerformed(evt);
            }
        });

        searchBookKonuTextField.setBackground(new java.awt.Color(204, 204, 204));
        searchBookKonuTextField.setForeground(new java.awt.Color(51, 51, 51));
        searchBookKonuTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBookKonuTextFieldActionPerformed(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(0, 102, 153));
        jLabel3.setForeground(new java.awt.Color(0, 153, 204));
        jLabel3.setText("Konu:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(searchBookAdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchBookYazarTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addComponent(searchBookAramaYapButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchBookKonuTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(searchBookAdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(searchBookKonuTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchBookYazarTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(searchBookAramaYapButton)
                .addContainerGap())
        );

        searchBookTumKitapGosterButton.setBackground(new java.awt.Color(51, 51, 51));
        searchBookTumKitapGosterButton.setForeground(new java.awt.Color(0, 153, 204));
        searchBookTumKitapGosterButton.setText("Bütün Kitapları Göster");
        searchBookTumKitapGosterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBookTumKitapGosterButtonActionPerformed(evt);
            }
        });

        backButton.setBackground(new java.awt.Color(51, 51, 51));
        backButton.setForeground(new java.awt.Color(0, 153, 204));
        backButton.setText("Geri Dön");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        searchBookKitapOduncAlButton.setBackground(new java.awt.Color(51, 51, 51));
        searchBookKitapOduncAlButton.setForeground(new java.awt.Color(0, 153, 204));
        searchBookKitapOduncAlButton.setText("Kitabı Ödünç Al");
        searchBookKitapOduncAlButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBookKitapOduncAlButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(searchBookTumKitapGosterButton, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                    .addComponent(backButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(searchBookKitapOduncAlButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(searchBookTumKitapGosterButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchBookKitapOduncAlButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(backButton)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchBookAdTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBookAdTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchBookAdTextFieldActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        if (loggedInUser != null) {
            new StudentHomepage(loggedInUser).setVisible(true);
            this.dispose();
        } else {
            // loggedInUser null ise, bir hata mesajı gösterilebilir
            JOptionPane.showMessageDialog(this, "Giriş yapmış bir kullanıcı bulunamadı.", "Hata", JOptionPane.ERROR_MESSAGE);
            // ya da bir hata durumunu nasıl ele almak istediğinize karar verin.
        }
    }//GEN-LAST:event_backButtonActionPerformed

    private void searchBookKonuTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBookKonuTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchBookKonuTextFieldActionPerformed

    private void searchBookYazarTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBookYazarTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchBookYazarTextFieldActionPerformed

    private void searchBookAramaYapButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBookAramaYapButtonActionPerformed
        // TODO add your handling code here:
         // TODO add your handling code here:
        String bookName = searchBookAdTextField.getText().trim();
        String author = searchBookYazarTextField.getText().trim();
        String subject = searchBookKonuTextField.getText().trim();

        // BookBuilder sınıfından bir örnek oluştur
        BookBuilder bookBuilder = new BookBuilder();

        // Kitap adına, yazarına ve konusuna göre arama yap
        List<Book> searchResults = bookBuilder.searchBooksByFilters(bookName, author, subject);

        // Arama sonuçlarını göster
        bookBuilder.displaySearchResults2(searchResults, kitapAraTable);

    }//GEN-LAST:event_searchBookAramaYapButtonActionPerformed
private boolean tabloGoruldu = false;
    private void searchBookTumKitapGosterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBookTumKitapGosterButtonActionPerformed
        if (!tabloGoruldu) {
            // Check if bookBuilder is not null before using it
            if (bookBuilder != null) {
                bookBuilder.displayAllBooksOnTable(tableModel);
                tabloGoruldu = true; // Bayrağı true yap
            }
    }
    }//GEN-LAST:event_searchBookTumKitapGosterButtonActionPerformed

    private void searchBookKitapOduncAlButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBookKitapOduncAlButtonActionPerformed
        try {
    DefaultTableModel model = (DefaultTableModel) kitapAraTable.getModel();
    String targetColumnName = "Kitap Adı";

    // Belirtilen sütunun indeksini bulun
    int columnIndex = -1;
    for (int i = 0; i < model.getColumnCount(); i++) {
        if (model.getColumnName(i).equals(targetColumnName)) {
            columnIndex = i;
            break;
        }
    }

    int selectedRowIndex = kitapAraTable.getSelectedRow();

    // Assuming the column index for book status is 1 (modify based on your structure)
    int statusColumnIndex = 3;  // Change this according to your actual column index

    String bookStatus = (String) model.getValueAt(selectedRowIndex, statusColumnIndex);

    if ("ODUNC_ALINDI".equals(bookStatus)) {
        // Kitap zaten ödünç alınmış, bu durumu kullanıcıya bildir
        JOptionPane.showMessageDialog(null, "Kitap zaten ödünç alınmış durumda. Başka bir kitap seçin.");
    } else {
        // Kitap ödünç alabilir durumda, işlemleri devam ettir
        try {
            String username = loggedInUser.getUsername();
            int userId = loggedInUser.getUserIdByUsername(username);
            String oldBookName = (String) model.getValueAt(selectedRowIndex, columnIndex);

            // O anki tarihi al
            LocalDate currentDate = LocalDate.now();

            // Tarih formatını belirle (isteğe bağlı)
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String formattedDate = currentDate.format(formatter);

            // return_date'i 10 gün sonrası olarak ayarla
            LocalDate returnDate = currentDate.plusDays(20);
            String formattedReturnDate = returnDate.format(formatter);

            BookBuilder bookBuilder = new BookBuilder();
            bookBuilder.addTBorrowDatabaseBook(userId, selectedRowIndex, formattedDate, formattedReturnDate);
            bookBuilder.makeBorrowedBookStatusInDatabase(oldBookName);

            // Kitap ödünç alındıysa, kullanıcıya bilgi mesajını göster
            JOptionPane.showMessageDialog(null, "Kitap başarıyla ödünç alındı.", "Başarılı", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Lütfen Kitap Seçin");
        }
    }
} catch (Exception ex) {
    JOptionPane.showMessageDialog(null, "Lütfen Kitap Seçin");
}
       

  try {
    DefaultTableModel model = (DefaultTableModel) kitapAraTable.getModel();
    String targetColumnName = "Kitap Adı";

    // Belirtilen sütunun indeksini bulun
    int columnIndex = -1;
    for (int i = 0; i < model.getColumnCount(); i++) {
        if (model.getColumnName(i).equals(targetColumnName)) {
            columnIndex = i;
            break;
        }
    }

    int selectedRowIndex = kitapAraTable.getSelectedRow();

    // Assuming the column index for book status is 1 (modify based on your structure)
    int statusColumnIndex = 3;  // Change this according to your actual column index

    String bookStatus = (String) model.getValueAt(selectedRowIndex, statusColumnIndex);

    if ("ODUNC_ALINDI".equals(bookStatus)) {
        // Kitap zaten ödünç alınmış, bu durumu kullanıcıya bildir
        JOptionPane.showMessageDialog(null, "Kitap zaten ödünç alınmış durumda. Başka bir kitap seçin.");
    } else {
        // Kitap ödünç alınabilir durumda, işlemleri devam ettir
        // TODO add your handling code here:
        try {
            String username = loggedInUser.getUsername();
            int userId = loggedInUser.getUserIdByUsername(username);
            String oldBookName = (String) model.getValueAt(selectedRowIndex, columnIndex);

            // O anki tarihi al
            LocalDate currentDate = LocalDate.now();

            // Tarih formatını belirle (isteğe bağlı)
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String formattedDate = currentDate.format(formatter);

            // return_date'i 10 gün sonrası olarak ayarla
            LocalDate returnDate = currentDate.plusDays(20);
            String formattedReturnDate = returnDate.format(formatter);

            BookBuilder bookBuilder = new BookBuilder();
            bookBuilder.addTBorrowDatabaseBook(userId, selectedRowIndex, formattedDate, formattedReturnDate);
            bookBuilder.makeBorrowedBookStatusInDatabase(oldBookName);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }
} catch (Exception ex) {
    JOptionPane.showMessageDialog(null, ex);

    }//GEN-LAST:event_searchBookKitapOduncAlButtonActionPerformed
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable kitapAraTable;
    private javax.swing.JTextField searchBookAdTextField;
    private javax.swing.JButton searchBookAramaYapButton;
    private javax.swing.JButton searchBookKitapOduncAlButton;
    private javax.swing.JTextField searchBookKonuTextField;
    private javax.swing.JButton searchBookTumKitapGosterButton;
    private javax.swing.JTextField searchBookYazarTextField;
    // End of variables declaration//GEN-END:variables
}
