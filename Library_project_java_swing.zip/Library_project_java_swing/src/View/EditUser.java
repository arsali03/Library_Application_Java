/*
Author Ali Arslan
*/
package View;

import DataBase.Users.RegularUser;
import DataBase.Users.RegularUserBuilder;
import DataBase.Users.RegularUserFactory;
import DataBase.Users.User;
import DataBase.Users.UserController;
import DataBase.Users.UserService;
import DataBase.Users.UserType;
import java.awt.Color;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class EditUser extends javax.swing.JFrame {

    private UserController userController;
    private User loggedInUser;
    
    public EditUser() {
        this.loggedInUser=loggedInUser;
        initComponents();
        initializeComponents();
        setSize(600, 400);
        setResizable(false);
        setLocation(400, 200);
        getContentPane().setBackground(new Color(40, 40, 40));
        setTitle("Kütüphane Uygulaması - Kullanıcı Düzenle");
    }

   private void initializeComponents() {
        userController = new UserController(new UserService(new RegularUserFactory()));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        editUserTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        editUserAraTextField = new javax.swing.JTextField();
        editUserAraButton = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        editUserUyeSilButton = new javax.swing.JButton();
        editUserUyeDuzenleButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        editUserEkleAdTextField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        editUserEkleSoyadTextField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        editUserEkleKAdıTextField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        editUserEkleTelefonNoTextField = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        editUserEkleMailTextField = new javax.swing.JTextField();
        editUserUyeEkleButton = new javax.swing.JButton();
        editUserEkleSifrePasswordField = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 153));

        jPanel3.setBackground(new java.awt.Color(0, 102, 153));

        jScrollPane2.setPreferredSize(new java.awt.Dimension(100, 80));

        editUserTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "K.Adı", "Adı", "Soyadı"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(editUserTable);
        if (editUserTable.getColumnModel().getColumnCount() > 0) {
            editUserTable.getColumnModel().getColumn(0).setResizable(false);
            editUserTable.getColumnModel().getColumn(1).setResizable(false);
            editUserTable.getColumnModel().getColumn(2).setResizable(false);
        }

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Üye Adı ve Soyadı");

        editUserAraTextField.setBackground(new java.awt.Color(204, 204, 204));
        editUserAraTextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        editUserAraTextField.setForeground(new java.awt.Color(51, 51, 51));
        editUserAraTextField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        editUserAraTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserAraTextFieldActionPerformed(evt);
            }
        });

        editUserAraButton.setBackground(new java.awt.Color(51, 51, 51));
        editUserAraButton.setForeground(new java.awt.Color(0, 153, 204));
        editUserAraButton.setText("Ara");
        editUserAraButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserAraButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(editUserAraTextField)
                    .addComponent(editUserAraButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editUserAraTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(editUserAraButton, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        editUserUyeSilButton.setBackground(new java.awt.Color(51, 51, 51));
        editUserUyeSilButton.setForeground(new java.awt.Color(0, 153, 204));
        editUserUyeSilButton.setText("Üye Sil");
        editUserUyeSilButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserUyeSilButtonActionPerformed(evt);
            }
        });

        editUserUyeDuzenleButton.setBackground(new java.awt.Color(51, 51, 51));
        editUserUyeDuzenleButton.setForeground(new java.awt.Color(0, 153, 204));
        editUserUyeDuzenleButton.setText("Üye Düzenle");
        editUserUyeDuzenleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserUyeDuzenleButtonActionPerformed(evt);
            }
        });

        backButton.setBackground(new java.awt.Color(51, 51, 51));
        backButton.setForeground(new java.awt.Color(0, 153, 204));
        backButton.setText("Geri Dön");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(editUserUyeSilButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(editUserUyeDuzenleButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(backButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(editUserUyeSilButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editUserUyeDuzenleButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addComponent(backButton)
                .addContainerGap())
        );

        jPanel6.setBackground(new java.awt.Color(0, 102, 153));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 153));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("ÜYE EKLE");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 153));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Ad:");

        editUserEkleAdTextField.setBackground(new java.awt.Color(204, 204, 204));
        editUserEkleAdTextField.setForeground(new java.awt.Color(51, 51, 51));
        editUserEkleAdTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserEkleAdTextFieldActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 153));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Soyad:");

        editUserEkleSoyadTextField.setBackground(new java.awt.Color(204, 204, 204));
        editUserEkleSoyadTextField.setForeground(new java.awt.Color(51, 51, 51));
        editUserEkleSoyadTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserEkleSoyadTextFieldActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 102, 153));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Kullanıcı Adı:");

        editUserEkleKAdıTextField.setBackground(new java.awt.Color(204, 204, 204));
        editUserEkleKAdıTextField.setForeground(new java.awt.Color(51, 51, 51));
        editUserEkleKAdıTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserEkleKAdıTextFieldActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 102, 153));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Şifre:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 102, 153));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Telefon No:");

        editUserEkleTelefonNoTextField.setBackground(new java.awt.Color(204, 204, 204));
        editUserEkleTelefonNoTextField.setForeground(new java.awt.Color(51, 51, 51));
        editUserEkleTelefonNoTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserEkleTelefonNoTextFieldActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 102, 153));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("E-Posta:");

        editUserEkleMailTextField.setBackground(new java.awt.Color(204, 204, 204));
        editUserEkleMailTextField.setForeground(new java.awt.Color(51, 51, 51));
        editUserEkleMailTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserEkleMailTextFieldActionPerformed(evt);
            }
        });

        editUserUyeEkleButton.setBackground(new java.awt.Color(51, 51, 51));
        editUserUyeEkleButton.setForeground(new java.awt.Color(0, 153, 204));
        editUserUyeEkleButton.setText("Üye Ekle");
        editUserUyeEkleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserUyeEkleButtonActionPerformed(evt);
            }
        });

        editUserEkleSifrePasswordField.setBackground(new java.awt.Color(204, 204, 204));
        editUserEkleSifrePasswordField.setForeground(new java.awt.Color(51, 51, 51));
        editUserEkleSifrePasswordField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editUserEkleSifrePasswordFieldActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(editUserEkleSoyadTextField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                            .addComponent(editUserEkleKAdıTextField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(editUserEkleTelefonNoTextField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(editUserEkleMailTextField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(editUserEkleAdTextField)
                            .addComponent(editUserUyeEkleButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(editUserEkleSifrePasswordField))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(45, 45, 45)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(editUserEkleAdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(editUserEkleSoyadTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(editUserEkleKAdıTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(editUserEkleSifrePasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(editUserEkleTelefonNoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(editUserEkleMailTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(editUserUyeEkleButton)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void editUserAraTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserAraTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editUserAraTextFieldActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        new AdminPage(loggedInUser).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    private void editUserUyeEkleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserUyeEkleButtonActionPerformed
        // TODO add your handling code here:
        String firstName = editUserEkleAdTextField.getText();
        String lastName = editUserEkleSoyadTextField.getText();
        String username = editUserEkleKAdıTextField.getText();
        UserType userType = UserType.USER;
        String password = new String(editUserEkleSifrePasswordField.getPassword());
        String phoneNumber = editUserEkleTelefonNoTextField.getText();
        String email = editUserEkleMailTextField.getText();
        // Kullanıcı kaydını gerçekleştir
        userController.registerUser(firstName, lastName, username, password, userType, phoneNumber, email);
    }//GEN-LAST:event_editUserUyeEkleButtonActionPerformed

    private void editUserEkleMailTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserEkleMailTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editUserEkleMailTextFieldActionPerformed

    private void editUserEkleTelefonNoTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserEkleTelefonNoTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editUserEkleTelefonNoTextFieldActionPerformed

    private void editUserEkleKAdıTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserEkleKAdıTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editUserEkleKAdıTextFieldActionPerformed

    private void editUserUyeDuzenleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserUyeDuzenleButtonActionPerformed
        // TODO add your handling code here:
        int selectedRow = editUserTable.getSelectedRow();
        
        if (selectedRow != -1) {
            // Table modelinden kullanıcının ID'sini al
            String kullaniciAdi = (String) editUserTable.getValueAt(selectedRow, 0);
            
            // UserController aracılığıyla kullanıcı bilgilerini al
            User selectedUser = userController.getUserByUsername(kullaniciAdi);
            
            if (selectedUser != null) {
            // Daha sonra bu kullanıcı bilgilerini MemberEdit formuna gönder
            MemberEdit memberEditForm = new MemberEdit(selectedUser);
            memberEditForm.setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Kullanıcı bilgileri alınamadı.", "Hata", JOptionPane.ERROR_MESSAGE);
        }
        } else {
            JOptionPane.showMessageDialog(this, "Lütfen bir kullanıcı seçin.", "Uyarı", JOptionPane.WARNING_MESSAGE);
        }
        
        
    }//GEN-LAST:event_editUserUyeDuzenleButtonActionPerformed

    private void editUserEkleSifrePasswordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserEkleSifrePasswordFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editUserEkleSifrePasswordFieldActionPerformed

    private void editUserAraButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserAraButtonActionPerformed
        // TODO add your handling code here:
        // Ad ve soyadı al
        String adSoyad = editUserAraTextField.getText().trim();

        // Eğer ad ve soyad boş ise uyarı göster
        if (adSoyad.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Lütfen ad ve soyad girin.", "Uyarı", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Arama işlemini gerçekleştir
        List<User> searchResults = userController.searchUsersByName(adSoyad);

        // Arama sonuçlarını tabloya ekle
        displaySearchResults(searchResults);
    }//GEN-LAST:event_editUserAraButtonActionPerformed
    
    private void displaySearchResults(List<User> searchResults) {
        // Controller sınıfındaki metodun çağrılması
        userController.displaySearchResults(searchResults, (DefaultTableModel) editUserTable.getModel());
    }
    
    private void editUserEkleAdTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserEkleAdTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editUserEkleAdTextFieldActionPerformed

    private void editUserUyeSilButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserUyeSilButtonActionPerformed
        // TODO add your handling code here:
        // Seçilen satırın index'ini al
        int selectedRow = editUserTable.getSelectedRow();
        // Seçili bir satır varsa devam et
        if (selectedRow != -1) {
            // Table modelinden kullanıcının ID'sini al
            String kullaniciAdi = (String) editUserTable.getValueAt(selectedRow, 0);
            
            RegularUserBuilder builder = RegularUserBuilder.builder();
            // Builder metodları kullanarak özelliklere değer atayın
            RegularUser user = builder
                .setUsername(kullaniciAdi)
                .build();
            
            // Kullanıcıyı silme işlemini gerçekleştir
            boolean isUserDeleted = userController.deleteUser(user);

            // Kullanıcı başarıyla silindiğinde yapılacak işlemler
            if (isUserDeleted) {
                JOptionPane.showMessageDialog(this, "Kullanıcı başarıyla silindi.", "Bilgi", JOptionPane.INFORMATION_MESSAGE);
                // Tabloyu güncelle
                
            } else {
                JOptionPane.showMessageDialog(this, "Kullanıcı silinemedi.", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Lütfen bir kullanıcı seçin.", "Uyarı", JOptionPane.WARNING_MESSAGE);
        }
        
    }//GEN-LAST:event_editUserUyeSilButtonActionPerformed
    
    
    
    private void editUserEkleSoyadTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editUserEkleSoyadTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editUserEkleSoyadTextFieldActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.JButton editUserAraButton;
    private javax.swing.JTextField editUserAraTextField;
    private javax.swing.JTextField editUserEkleAdTextField;
    private javax.swing.JTextField editUserEkleKAdıTextField;
    private javax.swing.JTextField editUserEkleMailTextField;
    private javax.swing.JPasswordField editUserEkleSifrePasswordField;
    private javax.swing.JTextField editUserEkleSoyadTextField;
    private javax.swing.JTextField editUserEkleTelefonNoTextField;
    private javax.swing.JTable editUserTable;
    private javax.swing.JButton editUserUyeDuzenleButton;
    private javax.swing.JButton editUserUyeEkleButton;
    private javax.swing.JButton editUserUyeSilButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
