package View;
/*
Author Ali Arslan
*/

import DataBase.DatabaseConnection;
import java.awt.Color;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import DataBase.Users.UserController;
import DataBase.Users.UserService;
import DataBase.Users.UserFactory;
import DataBase.Users.UserType;
import DataBase.Users.RegularUserFactory;

public class Register extends javax.swing.JFrame {
    
    private UserController userController;
    
    public Register() {
        initComponents();
        setSize(600, 400);
        setResizable(false);
        setLocation(400, 200);
        getContentPane().setBackground(new Color(40, 40, 40));
        setTitle("Kütüphane Uygulaması - Kayıt Ol");
        // UserController'ı başlatın
        UserFactory userFactory = new RegularUserFactory(); // veya AdminUserFactory
        UserService userService = new UserService(userFactory);
        userController = new UserController(userService);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel7 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        registerAd = new javax.swing.JTextField();
        registerKullaniciAdi = new javax.swing.JTextField();
        registerSoyad = new javax.swing.JTextField();
        registerSifre = new javax.swing.JPasswordField();
        registerKullaniciTuru = new javax.swing.JComboBox<>();
        kayitOlButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        registerTelNo = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        registerMail = new javax.swing.JTextField();
        registerSozlesmeCheckBox = new javax.swing.JCheckBox();
        jLabel9 = new javax.swing.JLabel();
        jPanel35 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel7.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 91, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 94, Short.MAX_VALUE)
        );

        jPanel6.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 88, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 87, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setBackground(new java.awt.Color(255, 102, 0));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Ad");

        jLabel3.setBackground(new java.awt.Color(255, 102, 0));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 204));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Soyad");

        jLabel4.setBackground(new java.awt.Color(255, 102, 0));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 204));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Kullanıcı Adı");

        jLabel5.setBackground(new java.awt.Color(255, 102, 0));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 153, 204));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Şifre");

        jLabel6.setBackground(new java.awt.Color(255, 102, 0));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 153, 204));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Kullanıcı ");

        registerAd.setBackground(new java.awt.Color(204, 204, 204));
        registerAd.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        registerAd.setForeground(new java.awt.Color(51, 51, 51));
        registerAd.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        registerAd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerAdActionPerformed(evt);
            }
        });

        registerKullaniciAdi.setBackground(new java.awt.Color(204, 204, 204));
        registerKullaniciAdi.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        registerKullaniciAdi.setForeground(new java.awt.Color(51, 51, 51));
        registerKullaniciAdi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        registerKullaniciAdi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerKullaniciAdiActionPerformed(evt);
            }
        });

        registerSoyad.setBackground(new java.awt.Color(204, 204, 204));
        registerSoyad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        registerSoyad.setForeground(new java.awt.Color(51, 51, 51));
        registerSoyad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        registerSoyad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerSoyadActionPerformed(evt);
            }
        });

        registerSifre.setBackground(new java.awt.Color(204, 204, 204));
        registerSifre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        registerSifre.setForeground(new java.awt.Color(51, 51, 51));
        registerSifre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        registerSifre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerSifreActionPerformed(evt);
            }
        });

        registerKullaniciTuru.setBackground(new java.awt.Color(204, 204, 204));
        registerKullaniciTuru.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        registerKullaniciTuru.setForeground(new java.awt.Color(51, 51, 51));
        registerKullaniciTuru.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Üye", "Admin" }));
        registerKullaniciTuru.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        registerKullaniciTuru.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerKullaniciTuruActionPerformed(evt);
            }
        });

        kayitOlButton.setBackground(new java.awt.Color(51, 51, 51));
        kayitOlButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        kayitOlButton.setForeground(new java.awt.Color(0, 153, 204));
        kayitOlButton.setText("Kayıt Ol");
        kayitOlButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kayitOlButtonActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(255, 102, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 153, 204));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Telefon No");

        registerTelNo.setBackground(new java.awt.Color(204, 204, 204));
        registerTelNo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        registerTelNo.setForeground(new java.awt.Color(51, 51, 51));
        registerTelNo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        registerTelNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerTelNoActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(255, 102, 0));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 204));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("E-Posta");

        registerMail.setBackground(new java.awt.Color(204, 204, 204));
        registerMail.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        registerMail.setForeground(new java.awt.Color(51, 51, 51));
        registerMail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        registerMail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerMailActionPerformed(evt);
            }
        });

        registerSozlesmeCheckBox.setBackground(new java.awt.Color(51, 51, 51));
        registerSozlesmeCheckBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        registerSozlesmeCheckBox.setForeground(new java.awt.Color(51, 51, 51));
        registerSozlesmeCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerSozlesmeCheckBoxActionPerformed(evt);
            }
        });

        jLabel9.setBackground(new java.awt.Color(0, 102, 204));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 153, 204));
        jLabel9.setText("Kullanıcı sözleşmesini okudum ve onaylıyorum !");

        jPanel35.setBackground(new java.awt.Color(0, 102, 153));
        jPanel35.setForeground(new java.awt.Color(0, 102, 102));
        jPanel35.setPreferredSize(new java.awt.Dimension(200, 388));

        jPanel22.setForeground(new java.awt.Color(30, 30, 30));
        jPanel22.setPreferredSize(new java.awt.Dimension(200, 388));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 9, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, 9, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(0, 102, 153));
        jPanel4.setForeground(new java.awt.Color(51, 51, 51));

        jPanel1.setForeground(new java.awt.Color(0, 153, 153));

        jLabel10.setBackground(new java.awt.Color(0, 102, 153));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 102, 153));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("KAYIT OL");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 420, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel10)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 32, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel10)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 420, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(65, 65, 65)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel2)
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(16, 16, 16))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(18, 18, 18)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(registerMail)
                                        .addComponent(registerTelNo, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(registerKullaniciTuru, javax.swing.GroupLayout.Alignment.TRAILING, 0, 200, Short.MAX_VALUE)
                                        .addComponent(registerSifre, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(registerKullaniciAdi, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(registerSoyad, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(registerAd, javax.swing.GroupLayout.Alignment.TRAILING)))
                                .addComponent(jLabel9))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(registerSozlesmeCheckBox)
                            .addGap(86, 86, 86))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(kayitOlButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(167, 167, 167)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(registerAd, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(registerSoyad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(registerKullaniciAdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(registerSifre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(registerKullaniciTuru, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(registerTelNo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(registerMail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(registerSozlesmeCheckBox, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(kayitOlButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel35, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void registerKullaniciTuruActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerKullaniciTuruActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_registerKullaniciTuruActionPerformed

    private void registerSifreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerSifreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_registerSifreActionPerformed

    private void kayitOlButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kayitOlButtonActionPerformed
        // TODO add your handling code here
        String firstName = registerAd.getText();
        String lastName = registerSoyad.getText();
        String username = registerKullaniciAdi.getText();
        String password = new String(registerSifre.getPassword());
        UserType userType = UserType.USER; // Varsayılan olarak Normal User
        String phoneNumber = registerTelNo.getText();
        String email = registerMail.getText();
        boolean sozlesme = registerSozlesmeCheckBox.isSelected();
        
        // Alanların boş olup olmadığını kontrol et
    if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty() || phoneNumber.isEmpty() || email.isEmpty() || !sozlesme) {
        JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun", "Hata", JOptionPane.ERROR_MESSAGE);
        return; // Eğer alanlar boşsa işlemi durdur
    }

    // Eğer kullanıcı tipi Admin seçiliyse ve giriş yapan kullanıcı admin değilse, hata mesajı göster
    if (registerKullaniciTuru.getSelectedItem().equals("Admin")) {
            JOptionPane.showMessageDialog(this, "Sadece adminler admin ekleyebilir", "Yetki Hatası", JOptionPane.ERROR_MESSAGE);
            {
        }
    } else if (userController.isUsernameExists(username)) {
        // Eğer kullanıcı adı daha önce kullanılmışsa, hata mesajı göster
        JOptionPane.showMessageDialog(this, "Bu kullanıcı adı zaten kullanılmış", "Hata", JOptionPane.ERROR_MESSAGE);
        return; // Eğer kullanıcı adı zaten varsa işlemi durdur
    } else {
        // Kullanıcı kaydını gerçekleştir
        userController.registerUser(firstName, lastName, username, password, userType, phoneNumber, email);
        this.dispose();
        new Login().setVisible(true);
    }
        
    }//GEN-LAST:event_kayitOlButtonActionPerformed

    private void registerTelNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerTelNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_registerTelNoActionPerformed

    private void registerMailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerMailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_registerMailActionPerformed

    private void registerSozlesmeCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerSozlesmeCheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_registerSozlesmeCheckBoxActionPerformed

    private void registerKullaniciAdiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerKullaniciAdiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_registerKullaniciAdiActionPerformed

    private void registerAdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerAdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_registerAdActionPerformed

    private void registerSoyadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerSoyadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_registerSoyadActionPerformed

    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton kayitOlButton;
    private javax.swing.JTextField registerAd;
    private javax.swing.JTextField registerKullaniciAdi;
    private javax.swing.JComboBox<String> registerKullaniciTuru;
    private javax.swing.JTextField registerMail;
    private javax.swing.JPasswordField registerSifre;
    private javax.swing.JTextField registerSoyad;
    private javax.swing.JCheckBox registerSozlesmeCheckBox;
    private javax.swing.JTextField registerTelNo;
    // End of variables declaration//GEN-END:variables

}
